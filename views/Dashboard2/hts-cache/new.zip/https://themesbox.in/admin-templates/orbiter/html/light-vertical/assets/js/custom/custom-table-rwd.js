/*
---------------------------------
    : Custom - Table RWD js :
---------------------------------
*/
"use strict";
$(document).ready(function() {
    /* -- Table - RWD -- */
    $('.rwd-table').responsiveTable('update');
});